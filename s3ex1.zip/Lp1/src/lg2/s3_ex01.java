package lg2;
import java.util.Scanner;
public class s3_ex01 {
	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int cont = 0, depositoMax = 0,depositoMin = 1;
        
        System.out.println("Insira o contador: ");
        cont = scan.nextInt();

        int[] notas = new int[cont];

        for (int i = 0; i<cont;i++) {
            System.out.println("Insira um n�mero: ");
            notas[i] = scan.nextInt();
        }
        depositoMin = notas[0];
        for (int i = 0; i<cont-1;i++) {
            if (notas[i] > depositoMax) {
                depositoMax = notas[i];
            }
            if (notas[i] < depositoMin) {
                depositoMin = notas[i];
            }
        }
        System.out.println("Maior n�mero: " + depositoMax);
        System.out.println("Menor n�mero: " + depositoMin);
        scan.close();
    }
}



